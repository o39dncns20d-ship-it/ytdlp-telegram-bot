import asyncio
import logging
import os
import re
import shutil
import socket
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse
from ipaddress import ip_address

import yt_dlp
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
    InputFile
)
from telegram.constants import ChatAction
from telegram.error import TelegramError
from telegram.ext import (
    Application, CallbackQueryHandler, CommandHandler,
    ContextTypes, MessageHandler, filters
)

# ---------------- Configuration ----------------
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
MAX_FILE_MB = int(os.getenv("MAX_FILE_MB", "49"))
MAX_FILE_BYTES = MAX_FILE_MB * 1024 * 1024
MAX_DURATION_SECONDS = int(os.getenv("MAX_DURATION_SECONDS", str(4 * 60 * 60)))
MAX_QUEUE_PER_USER = int(os.getenv("MAX_QUEUE_PER_USER", "3"))
MAX_GLOBAL_CONCURRENT = int(os.getenv("MAX_GLOBAL_CONCURRENT", "1"))
DOWNLOAD_DIR = Path(os.getenv("DOWNLOAD_DIR", "downloads")).resolve()
LANG_DEFAULT = os.getenv("BOT_LANGUAGE", "ar").lower()
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("media-bot")

DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Small in-memory state is suitable for a single process. Use Redis/DB for
# multiple replicas or durable queues.
@dataclass
class Job:
    user_id: int
    chat_id: int
    message_id: int
    url: str
    mode: str                 # "video" or "audio"
    quality: str              # "best", "1080", "720", "480", "360"
    title: str = "media"
    progress: dict = field(default_factory=dict)
    status_message_id: int | None = None
    queued_at: float = field(default_factory=time.time)

job_queue: asyncio.Queue[Job] = asyncio.Queue()
user_pending: dict[int, int] = {}
active_urls: dict[tuple[int, str], float] = {}
SUPPORTED_QUALITIES = {"best", "1080", "720", "480", "360"}
URL_RE = re.compile(r"https?://\S+", re.IGNORECASE)


def tr(lang: str, ar: str, en: str) -> str:
    return ar if lang == "ar" else en


def user_lang(context: ContextTypes.DEFAULT_TYPE) -> str:
    return context.user_data.get("lang", LANG_DEFAULT if LANG_DEFAULT in ("ar", "en") else "ar")


def valid_public_http_url(raw: str) -> bool:
    """Basic URL validation. Reject local/private literal IPs and localhost.
    This is defense-in-depth, not a complete SSRF sandbox."""
    try:
        p = urlparse(raw.strip())
        if p.scheme not in ("http", "https") or not p.hostname:
            return False
        host = p.hostname.lower().rstrip(".")
        if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
            return False
        try:
            ip = ip_address(host)
            if not ip.is_global:
                return False
        except ValueError:
            # Hostname is allowed; production deployments should add network
            # egress restrictions to block private/reserved destinations.
            pass
        return True
    except Exception:
        return False


def ydl_base_options() -> dict:
    return {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "socket_timeout": 25,
        "retries": 2,
        "fragment_retries": 2,
        "ignoreerrors": False,
        "restrictfilenames": True,
        "windowsfilenames": True,
        "cachedir": False,
    }


def inspect_media(url: str) -> dict:
    opts = ydl_base_options()
    opts.update({"skip_download": True, "extract_flat": False})
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=False)
    if not info:
        raise ValueError("Could not read media metadata.")
    if info.get("is_live"):
        raise ValueError("Live streams are not supported.")
    duration = info.get("duration")
    if duration and duration > MAX_DURATION_SECONDS:
        raise ValueError(f"Duration exceeds the configured limit ({MAX_DURATION_SECONDS // 3600} hours).")
    return {
        "title": (info.get("title") or "media")[:180],
        "duration": duration,
        "formats": info.get("formats") or [],
        "extractor": info.get("extractor_key") or info.get("extractor") or "unknown",
    }


def format_duration(seconds):
    if not seconds:
        return "—"
    seconds = int(seconds)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def make_choice_keyboard(lang: str, key: str) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(tr(lang, "🎬 فيديو", "🎬 Video"), callback_data=f"mode:video:{key}"),
            InlineKeyboardButton(tr(lang, "🎵 صوت MP3", "🎵 Audio MP3"), callback_data=f"mode:audio:{key}"),
        ],
        [InlineKeyboardButton(tr(lang, "🌐 تغيير اللغة", "🌐 Change language"), callback_data="lang:toggle")],
    ]
    return InlineKeyboardMarkup(rows)


def make_quality_keyboard(lang: str, mode: str, key: str) -> InlineKeyboardMarkup:
    if mode == "audio":
        rows = [[InlineKeyboardButton("MP3 · 192 kbps", callback_data=f"get:audio:best:{key}")]]
    else:
        rows = [
            [
                InlineKeyboardButton("1080p", callback_data=f"get:video:1080:{key}"),
                InlineKeyboardButton("720p", callback_data=f"get:video:720:{key}"),
            ],
            [
                InlineKeyboardButton("480p", callback_data=f"get:video:480:{key}"),
                InlineKeyboardButton("360p", callback_data=f"get:video:360:{key}"),
            ],
            [InlineKeyboardButton(tr(lang, "أفضل جودة متاحة", "Best available"), callback_data=f"get:video:best:{key}")],
        ]
    rows.append([InlineKeyboardButton(tr(lang, "↩️ رجوع", "↩️ Back"), callback_data=f"back:{key}")])
    return InlineKeyboardMarkup(rows)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lang = user_lang(context)
    await update.effective_message.reply_text(
        tr(lang,
           "أهلًا بك في بوت تحميل الوسائط 📥\n\nأرسل رابطًا عامًا من موقع متوافق، ثم اختر فيديو أو صوت والجودة المطلوبة.\n\n"
           "الأوامر:\n/language — تغيير اللغة\n/queue — عدد طلباتك المنتظرة\n/cancel — إلغاء الطلبات المنتظرة لك\n\n"
           "استخدم البوت للمحتوى الذي تملك حق تنزيله. لا يدعم تجاوز تسجيل الدخول أو الحماية.",
           "Welcome to the media downloader 📥\n\nSend a public URL from a supported site, then choose video/audio and quality.\n\n"
           "Commands:\n/language — change language\n/queue — your queued jobs\n/cancel — cancel your queued jobs\n\n"
           "Only download content you have permission to save. The bot does not bypass login or access controls.")
    )


async def language_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lang = user_lang(context)
    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton("العربية", callback_data="lang:set:ar"),
        InlineKeyboardButton("English", callback_data="lang:set:en"),
    ]])
    await update.effective_message.reply_text(tr(lang, "اختر لغة الواجهة:", "Choose the interface language:"), reply_markup=keyboard)


async def queue_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    lang = user_lang(context)
    n = user_pending.get(uid, 0)
    await update.effective_message.reply_text(
        tr(lang, f"طلباتك النشطة أو المنتظرة: {n}", f"Your active or queued jobs: {n}")
    )


async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    lang = user_lang(context)
    # Queue.Queue has no efficient arbitrary removal; jobs are marked by a set.
    cancelled_users.add(uid)
    await update.effective_message.reply_text(
        tr(lang, "تم طلب إلغاء الطلبات المنتظرة. إذا كان هناك تحميل جارٍ فسينتهي أو يفشل قبل بدء طلب آخر.",
           "Cancellation requested for queued jobs. An active download may finish or fail before the next job starts.")
    )


cancelled_users: set[int] = set()
pending_meta: dict[str, dict] = {}
pending_counter = 0


async def handle_url(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global pending_counter
    msg = update.effective_message
    uid = update.effective_user.id
    lang = user_lang(context)
    match = URL_RE.search(msg.text or "")
    if not match:
        return
    url = match.group(0).rstrip(".,!?)»]")
    if not valid_public_http_url(url):
        await msg.reply_text(tr(lang, "الرابط غير صالح أو غير مسموح به. أرسل رابط HTTP/HTTPS عامًا.",
                               "Invalid or disallowed URL. Send a public HTTP/HTTPS URL."))
        return
    if user_pending.get(uid, 0) >= MAX_QUEUE_PER_USER:
        await msg.reply_text(tr(lang, "لديك طلبات كثيرة قيد التنفيذ. انتظر حتى ينتهي أحدها.",
                               "You have too many active/queued jobs. Wait for one to finish."))
        return

    status = await msg.reply_text(tr(lang, "🔎 أفحص الرابط والمعلومات المتاحة…", "🔎 Checking URL and available metadata…"))
    try:
        info = await asyncio.to_thread(inspect_media, url)
    except Exception as exc:
        log.info("Metadata extraction failed: %s", exc)
        await status.edit_text(
            tr(lang,
               "تعذر قراءة الرابط. قد يكون الموقع غير مدعوم، أو يتطلب تسجيل دخول، أو يمنع الوصول، أو أن الرابط غير صالح.",
               "Could not read this URL. The site may be unsupported, require login, block access, or the URL may be invalid.")
        )
        return

    pending_counter += 1
    key = f"{uid:x}{pending_counter:x}"
    pending_meta[key] = {"url": url, "info": info, "user_id": uid, "created": time.time()}
    # Keep the in-memory map bounded.
    now = time.time()
    for k in list(pending_meta):
        if now - pending_meta[k]["created"] > 3600:
            pending_meta.pop(k, None)

    title = info["title"]
    details = f"{title}\n⏱ {format_duration(info['duration'])}\n🌐 {info['extractor']}"
    await status.edit_text(
        tr(lang, "اختر نوع التحميل:\n\n", "Choose download type:\n\n") + details,
        reply_markup=make_choice_keyboard(lang, key)
    )


async def callbacks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    lang = user_lang(context)
    data = query.data or ""

    if data == "lang:toggle":
        new_lang = "en" if lang == "ar" else "ar"
        context.user_data["lang"] = new_lang
        await query.edit_message_text(tr(new_lang, "تم تغيير اللغة. أرسل /start لعرض التعليمات.", "Language changed. Send /start to view instructions."))
        return
    if data.startswith("lang:set:"):
        context.user_data["lang"] = data.split(":")[-1]
        new_lang = user_lang(context)
        await query.edit_message_text(tr(new_lang, "تم ضبط اللغة. أرسل /start لعرض التعليمات.", "Language saved. Send /start to view instructions."))
        return

    parts = data.split(":")
    if parts[0] == "mode" and len(parts) == 3:
        mode, key = parts[1], parts[2]
        meta = pending_meta.get(key)
        if not meta or meta["user_id"] != query.from_user.id:
            await query.edit_message_text(tr(lang, "انتهت صلاحية هذا الاختيار. أرسل الرابط مجددًا.", "This choice expired. Send the URL again."))
            return
        await query.edit_message_text(
            tr(lang, "اختر الجودة:", "Choose quality:"),
            reply_markup=make_quality_keyboard(lang, mode, key)
        )
        return
    if parts[0] == "back" and len(parts) == 2:
        key = parts[1]
        meta = pending_meta.get(key)
        if not meta or meta["user_id"] != query.from_user.id:
            await query.edit_message_text(tr(lang, "انتهت صلاحية هذا الاختيار.", "This choice expired."))
            return
        await query.edit_message_text(
            tr(lang, "اختر نوع التحميل:\n\n", "Choose download type:\n\n") + meta["info"]["title"],
            reply_markup=make_choice_keyboard(lang, key)
        )
        return
    if parts[0] == "get" and len(parts) == 4:
        _, mode, quality, key = parts
        meta = pending_meta.get(key)
        if not meta or meta["user_id"] != query.from_user.id:
            await query.edit_message_text(tr(lang, "انتهت صلاحية هذا الاختيار. أرسل الرابط مجددًا.", "This choice expired. Send the URL again."))
            return
        if quality not in SUPPORTED_QUALITIES or mode not in {"video", "audio"}:
            await query.edit_message_text(tr(lang, "اختيار غير صالح.", "Invalid selection."))
            return
        uid = query.from_user.id
        if user_pending.get(uid, 0) >= MAX_QUEUE_PER_USER:
            await query.edit_message_text(tr(lang, "وصلت إلى حد الطلبات المسموح به. جرّب لاحقًا.", "Your queue limit has been reached. Try again later."))
            return
        job = Job(
            user_id=uid,
            chat_id=query.message.chat_id,
            message_id=query.message.message_id,
            url=meta["url"],
            mode=mode,
            quality=quality,
            title=meta["info"]["title"],
        )
        user_pending[uid] = user_pending.get(uid, 0) + 1
        cancelled_users.discard(uid)
        await job_queue.put(job)
        pending_meta.pop(key, None)
        await query.edit_message_text(
            tr(lang, f"✅ أُضيف طلبك إلى قائمة الانتظار.\nالموقع: {meta['info']['extractor']}\nالطلبات المنتظرة: {job_queue.qsize()}",
               f"✅ Added to the queue.\nSite: {meta['info']['extractor']}\nJobs waiting: {job_queue.qsize()}")
        )
        return


def progress_hook_factory(job: Job):
    def hook(data):
        status = data.get("status")
        if status == "downloading":
            total = data.get("total_bytes") or data.get("total_bytes_estimate") or 0
            downloaded = data.get("downloaded_bytes") or 0
            percent = (downloaded / total * 100) if total else 0
            job.progress.update({
                "status": "downloading",
                "percent": max(0, min(100, percent)),
                "downloaded": downloaded,
                "total": total,
                "speed": data.get("速度") or data.get("speed"),
                "eta": data.get("eta"),
            })
        elif status == "finished":
            job.progress.update({"status": "processing", "percent": 100})
    return hook


def download_media(job: Job, outdir: Path) -> Path:
    progress_hook = progress_hook_factory(job)
    if job.mode == "audio":
        fmt = "bestaudio/best"
        postprocessors = [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}]
    else:
        if job.quality == "best":
            fmt = "bestvideo[height<=1080]+bestaudio/best[height<=1080]/best"
        else:
            h = int(job.quality)
            fmt = f"bestvideo[height<={h}]+bestaudio/best[height<={h}]/best[height<={h}]"
        postprocessors = [{"key": "FFmpegVideoRemuxer", "preferedformat": "mp4"}]

    opts = ydl_base_options()
    opts.update({
        "format": fmt,
        "outtmpl": str(outdir / "%(title).150B_%(id)s.%(ext)s"),
        "progress_hooks": [progress_hook],
        "noplaylist": True,
        "max_filesize": MAX_FILE_BYTES,
        "postprocessors": postprocessors,
        "merge_output_format": "mp4",
        "continuedl": True,
    })
    with yt_dlp.YoutubeDL(opts) as ydl:
        ydl.download([job.url])

    files = [p for p in outdir.iterdir() if p.is_file() and p.stat().st_size > 0]
    if not files:
        raise RuntimeError("Download completed but no output file was found.")
    return max(files, key=lambda p: p.stat().st_mtime)


async def edit_progress(context, chat_id: int, message_id: int, job: Job):
    lang = "ar"
    last_text = None
    while job.progress.get("status") not in {"processing", "done", "error"}:
        p = job.progress.copy()
        if p.get("status") == "downloading":
            pct = p.get("percent", 0)
            filled = int(pct // 10)
            bar = "█" * filled + "░" * (10 - filled)
            text = f"⬇️ جاري التحميل…\n[{bar}] {pct:.1f}%"
        else:
            text = "⏳ جارٍ تجهيز التحميل…"
        if text != last_text:
            try:
                await context.bot.edit_message_text(text, chat_id=chat_id, message_id=message_id)
            except TelegramError:
                pass
            last_text = text
        await asyncio.sleep(3)


async def worker(app: Application):
    while True:
        job = await job_queue.get()
        uid = job.user_id
        lang = "ar"
        status_msg = None
        try:
            if uid in cancelled_users:
                continue
            status_msg = await app.bot.send_message(
                chat_id=job.chat_id,
                text=f"⏳ بدأ تجهيز: {job.title[:100]}"
            )
            job.status_message_id = status_msg.message_id
            job.progress["status"] = "starting"
            progress_task = asyncio.create_task(edit_progress(app, job.chat_id, status_msg.message_id, job))
            with tempfile.TemporaryDirectory(prefix="tgmedia_", dir=str(DOWNLOAD_DIR)) as temp:
                outdir = Path(temp)
                path = await asyncio.to_thread(download_media, job, outdir)
                job.progress["status"] = "processing"
                if not path.exists():
                    raise RuntimeError("Output file disappeared.")
                size = path.stat().st_size
                if size > MAX_FILE_BYTES:
                    raise RuntimeError(f"File is too large ({size // (1024*1024)} MB; limit {MAX_FILE_MB} MB).")
                await app.bot.edit_message_text(
                    text="📤 جارٍ إرسال الملف إلى تيليجرام…",
                    chat_id=job.chat_id, message_id=status_msg.message_id
                )
                await app.bot.send_chat_action(job.chat_id, ChatAction.UPLOAD_DOCUMENT)
                caption = (job.title or path.stem)[:900]
                with path.open("rb") as f:
                    if job.mode == "audio":
                        await app.bot.send_audio(
                            chat_id=job.chat_id, audio=f, filename=path.name,
                            title=caption[:64], caption=caption, read_timeout=180, write_timeout=180,
                            connect_timeout=30, pool_timeout=30
                        )
                    elif path.suffix.lower() in {".mp4", ".m4v", ".mov"}:
                        await app.bot.send_video(
                            chat_id=job.chat_id, video=f, filename=path.name,
                            caption=caption, supports_streaming=True,
                            read_timeout=180, write_timeout=180, connect_timeout=30, pool_timeout=30
                        )
                    else:
                        await app.bot.send_document(
                            chat_id=job.chat_id, document=f, filename=path.name,
                            caption=caption, read_timeout=180, write_timeout=180,
                            connect_timeout=30, pool_timeout=30
                        )
                try:
                    await app.bot.delete_message(job.chat_id, status_msg.message_id)
                except TelegramError:
                    pass
                job.progress["status"] = "done"
            progress_task.cancel()
        except Exception as exc:
            log.exception("Job failed")
            job.progress["status"] = "error"
            message = str(exc)
            if "File is larger than max-filesize" in message or "max-filesize" in message.lower():
                friendly = f"الملف أكبر من الحد المضبوط ({MAX_FILE_MB} MB). جرّب جودة أقل."
            elif "ffmpeg" in message.lower():
                friendly = "تعذر تحويل الوسائط. تأكد من تثبيت FFmpeg على السيرفر."
            else:
                friendly = "تعذر إكمال التحميل أو الإرسال. قد يكون الموقع غير متاح أو الملف أكبر من الحد المسموح."
            try:
                if status_msg:
                    await app.bot.edit_message_text(f"❌ {friendly}", chat_id=job.chat_id, message_id=status_msg.message_id)
                else:
                    await app.bot.send_message(job.chat_id, f"❌ {friendly}")
            except TelegramError:
                pass
        finally:
            user_pending[uid] = max(0, user_pending.get(uid, 1) - 1)
            if user_pending[uid] == 0:
                user_pending.pop(uid, None)
            job_queue.task_done()


async def post_init(app: Application):
    for _ in range(max(1, MAX_GLOBAL_CONCURRENT)):
        app.create_task(worker(app), name="download-worker")


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    log.exception("Unhandled bot error", exc_info=context.error)


def main():
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN is missing. Copy .env.example to .env and set your token.")
    if shutil.which("ffmpeg") is None:
        log.warning("FFmpeg was not found on PATH; audio extraction and format merging may fail.")
    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("language", language_command))
    app.add_handler(CommandHandler("queue", queue_command))
    app.add_handler(CommandHandler("cancel", cancel_command))
    app.add_handler(CallbackQueryHandler(callbacks))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_url))
    app.add_error_handler(error_handler)
    log.info("Bot is starting")
    app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=False)


if __name__ == "__main__":
    main()
